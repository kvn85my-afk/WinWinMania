WIN WIN MANIA V2
================
Polished prototype using the supplied casino artwork as the visual foundation.

Features:
- Full-screen purple/gold casino interface
- 5x3 playable reels
- Spin animation
- Balance, bet, and win values
- Basic win calculation
- Background music
- Spin, stop, win, and big-win sound effects
- Sound on/off button

Package: com.winwinmania.game
Version: 2.0
