package com.winwinmania.game

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.graphics.Color
import android.graphics.Typeface
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    private val handler = Handler(Looper.getMainLooper())
    private val symbols = listOf("🔔","🍒","💎","7","⭐","BAR","🍉","🍊","🍋","🍇","👑")
    private val cells = mutableListOf<TextView>()
    private lateinit var balance: TextView
    private lateinit var betText: TextView
    private lateinit var winText: TextView
    private lateinit var spinButton: Button
    private lateinit var soundButton: Button

    private var coins = 9_999_999_999L
    private var bet = 250_000L
    private var soundOn = true
    private var bgm: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        setContentView(buildUi())
        startBgm()
    }

    private fun buildUi(): View {
        val root = FrameLayout(this)

        val bg = ImageView(this).apply {
            setImageResource(com.winwinmania.game.R.drawable.casino_reference)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        root.addView(bg, FrameLayout.LayoutParams(-1, -1))

        // Live balance overlays the reference value
        balance = label("9,999,999,999", 17f, Color.WHITE).apply {
            setShadowLayer(4f, 0f, 2f, Color.BLACK)
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(balance, FrameLayout.LayoutParams(dp(235), dp(42)).apply {
            leftMargin = dp(95); topMargin = dp(19)
        })

        // Interactive live reels over the reel window.
        val reelBox = GridLayout(this).apply {
            rowCount = 3
            columnCount = 5
            setPadding(dp(2), dp(2), dp(2), dp(2))
            setBackgroundColor(0x66000000)
        }
        repeat(15) {
            val t = label(symbols.random(), 27f, Color.WHITE).apply {
                gravity = Gravity.CENTER
                setBackgroundColor(0x66100018)
                setShadowLayer(5f, 0f, 2f, Color.BLACK)
                typeface = Typeface.DEFAULT_BOLD
            }
            cells += t
            reelBox.addView(t, GridLayout.LayoutParams().apply {
                width = 0; height = 0
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(1), dp(1), dp(1), dp(1))
            })
        }
        root.addView(reelBox, FrameLayout.LayoutParams(-1, dp(365)).apply {
            leftMargin = dp(38); rightMargin = dp(38); topMargin = dp(385)
        })

        betText = label("250,000", 17f, 0xFFFFE082.toInt()).apply {
            gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(betText, FrameLayout.LayoutParams(dp(135), dp(54)).apply {
            leftMargin = dp(172); topMargin = dp(802)
        })

        winText = label("0", 17f, 0xFFFFFF66.toInt()).apply {
            gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(winText, FrameLayout.LayoutParams(dp(155), dp(54)).apply {
            leftMargin = dp(410); topMargin = dp(802)
        })

        val minus = smallButton("−") {
            bet = (bet / 2).coerceAtLeast(1_000)
            refresh()
        }
        root.addView(minus, FrameLayout.LayoutParams(dp(58), dp(56)).apply {
            leftMargin = dp(105); topMargin = dp(800)
        })

        val plus = smallButton("+") {
            bet = (bet * 2).coerceAtMost(5_000_000)
            refresh()
        }
        root.addView(plus, FrameLayout.LayoutParams(dp(58), dp(56)).apply {
            leftMargin = dp(304); topMargin = dp(800)
        })

        spinButton = Button(this).apply {
            text = "SPIN\nHOLD FOR AUTO"
            textSize = 24f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setBackgroundColor(0xFF168A20.toInt())
            setOnClickListener { spin() }
        }
        root.addView(spinButton, FrameLayout.LayoutParams(dp(250), dp(158), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(885)
        })

        soundButton = smallButton("🔊") {
            soundOn = !soundOn
            soundButton.text = if (soundOn) "🔊" else "🔇"
            if (soundOn) startBgm() else stopBgm()
        }
        root.addView(soundButton, FrameLayout.LayoutParams(dp(58), dp(48)).apply {
            leftMargin = dp(12); topMargin = dp(1085)
        })

        return root
    }

    private fun spin() {
        if (coins < bet) {
            Toast.makeText(this, "Not enough coins", Toast.LENGTH_SHORT).show()
            return
        }
        coins -= bet
        winText.text = "0"
        refresh()
        play(com.winwinmania.game.R.raw.spin)
        spinButton.isEnabled = false

        repeat(12) { tick ->
            handler.postDelayed({
                cells.forEach { it.text = symbols.random() }
            }, tick * 70L)
        }

        handler.postDelayed({
            val finalSymbols = MutableList(15) { symbols.random() }
            // 22% chance to create a visible 3+ match on a row.
            if (Random.nextInt(100) < 22) {
                val row = Random.nextInt(3)
                val sym = symbols.random()
                val start = row * 5
                finalSymbols[start] = sym
                finalSymbols[start + 1] = sym
                finalSymbols[start + 2] = sym
            }
            finalSymbols.forEachIndexed { i, s -> cells[i].text = s }

            var win = 0L
            for (row in 0..2) {
                val rowSymbols = finalSymbols.subList(row*5, row*5+5)
                val max = rowSymbols.groupingBy { it }.eachCount().values.maxOrNull() ?: 1
                if (max >= 3) win += bet * when(max) { 3 -> 3; 4 -> 8; else -> 20 }
            }
            coins += win
            winText.text = "%,d".format(win)
            refresh()
            if (win > 0) {
                play(if (win >= bet * 8) com.winwinmania.game.R.raw.bigwin else com.winwinmania.game.R.raw.win)
                pulse(winText)
                if (win >= bet * 8) Toast.makeText(this, "BIG WIN!  %,d".format(win), Toast.LENGTH_LONG).show()
            } else {
                play(com.winwinmania.game.R.raw.stop)
            }
            spinButton.isEnabled = true
        }, 950)
    }

    private fun pulse(v: View) {
        val a = ObjectAnimator.ofFloat(v, "scaleX", 1f, 1.35f, 1f)
        val b = ObjectAnimator.ofFloat(v, "scaleY", 1f, 1.35f, 1f)
        AnimatorSet().apply { playTogether(a,b); duration = 650; start() }
    }

    private fun label(s: String, size: Float, color: Int) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
    }

    private fun smallButton(s: String, action: () -> Unit) = Button(this).apply {
        text = s; textSize = 20f; setTextColor(Color.WHITE)
        setBackgroundColor(0xFF5B168F.toInt())
        setOnClickListener { action() }
    }

    private fun refresh() {
        balance.text = "%,d".format(coins)
        betText.text = "%,d".format(bet)
    }

    private fun play(resId: Int) {
        if (!soundOn) return
        MediaPlayer.create(this, resId)?.apply {
            setOnCompletionListener { it.release() }
            start()
        }
    }

    private fun startBgm() {
        if (!soundOn || bgm != null) return
        bgm = MediaPlayer.create(this, com.winwinmania.game.R.raw.bg_music).apply {
            isLooping = true
            setVolume(0.18f, 0.18f)
            start()
        }
    }

    private fun stopBgm() {
        bgm?.stop()
        bgm?.release()
        bgm = null
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    override fun onPause() {
        super.onPause()
        bgm?.pause()
    }

    override fun onResume() {
        super.onResume()
        if (soundOn && bgm != null) bgm?.start()
    }

    override fun onDestroy() {
        stopBgm()
        super.onDestroy()
    }
}
