WIN WIN MANIA
==============
Fresh Android prototype.

GitHub:
1. Create a new repository named WinWinMania.
2. Upload the CONTENTS of this ZIP to the repository root.
3. Open Actions.
4. Wait for "Build WinWinMania APK" to turn green.
5. Download the WinWinMania-APK artifact.
6. Extract it and install app-debug.apk.

Package: com.winwinmania.game
App name: Win Win Mania
