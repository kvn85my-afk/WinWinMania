package com.winwinmania.game

import android.animation.ObjectAnimator
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    private val symbols = listOf("🔔","🍒","💎","7","⭐","BAR","🍉","🍊","🍋","🍇","👑")
    private val cells = mutableListOf<TextView>()
    private lateinit var balanceText: TextView
    private lateinit var winText: TextView
    private lateinit var betText: TextView
    private var balance = 100000L
    private var bet = 1000L
    private val tone = ToneGenerator(AudioManager.STREAM_MUSIC, 70)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN
        setContentView(buildUi())
        refresh()
    }

    private fun buildUi(): View {
        val bg = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(0xFF10001F.toInt())
        }

        val top = TextView(this).apply {
            text = "🪙 100,000        LV. 1 ⭐"
            textSize = 18f; setTextColor(0xFFFFE082.toInt()); gravity = Gravity.CENTER
        }
        bg.addView(top, LinearLayout.LayoutParams(-1, -2))

        val title = TextView(this).apply {
            text = "♛\nWIN WIN\nMANIA"
            textSize = 38f; gravity = Gravity.CENTER
            setTextColor(0xFFFFC107.toInt())
            setShadowLayer(12f, 0f, 0f, 0xFFFF6F00.toInt())
        }
        bg.addView(title, LinearLayout.LayoutParams(-1, 0, 1.2f))

        val jackpot = TextView(this).apply {
            text = "GRAND 50,000,000   MAJOR 5,000,000\nMINOR 1,000,000     MINI 200,000"
            textSize = 15f; gravity = Gravity.CENTER
            setTextColor(0xFFFFFF66.toInt())
            setBackgroundColor(0xFF30004F.toInt())
            setPadding(8,12,8,12)
        }
        bg.addView(jackpot, LinearLayout.LayoutParams(-1, -2))

        val reels = GridLayout(this).apply {
            rowCount = 3; columnCount = 5
            setPadding(5, 12, 5, 12)
            setBackgroundColor(0xFF08000F.toInt())
        }
        repeat(15) {
            val cell = TextView(this).apply {
                text = symbols.random()
                textSize = 31f
                gravity = Gravity.CENTER
                setTextColor(0xFFFFFFFF.toInt())
                setBackgroundColor(0xFF180022.toInt())
                setPadding(4,12,4,12)
            }
            cells += cell
            reels.addView(cell, GridLayout.LayoutParams().apply {
                width = 0
                height = 0
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(2,2,2,2)
            })
        }
        bg.addView(reels, LinearLayout.LayoutParams(-1, 0, 3.3f))

        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val minus = button("−") { if (bet > 100) { bet /= 2; refresh() } }
        betText = stat("BET\n1,000")
        winText = stat("WIN\n0")
        val plus = button("+") { if (bet < balance) { bet *= 2; refresh() } }
        stats.addView(minus); stats.addView(betText, LinearLayout.LayoutParams(0,-2,1f))
        stats.addView(winText, LinearLayout.LayoutParams(0,-2,1f)); stats.addView(plus)
        bg.addView(stats, LinearLayout.LayoutParams(-1,-2))

        balanceText = stat("BALANCE 100,000")
        bg.addView(balanceText, LinearLayout.LayoutParams(-1,-2))

        val spin = Button(this).apply {
            text = "SPIN\nHOLD FOR AUTO"; textSize = 25f
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF20A020.toInt())
            setOnClickListener { spin() }
        }
        bg.addView(spin, LinearLayout.LayoutParams(-1, 0, 1f).apply { setMargins(55,10,55,8) })

        val menu = TextView(this).apply {
            text = "🛒 STORE       🎁 DAILY       ⭐ MISSIONS       ••• MORE"
            gravity = Gravity.CENTER; textSize = 13f; setTextColor(0xFFFFD54F.toInt())
        }
        bg.addView(menu, LinearLayout.LayoutParams(-1,-2))
        return bg
    }

    private fun stat(s:String)=TextView(this).apply {
        text=s; gravity=Gravity.CENTER; textSize=16f; setTextColor(0xFFFFE082.toInt()); setPadding(8,8,8,8)
    }
    private fun button(s:String, f:()->Unit)=Button(this).apply { text=s; setOnClickListener{f()} }

    private fun spin() {
        if (balance < bet) return
        balance -= bet
        tone.startTone(ToneGenerator.TONE_PROP_BEEP, 100)
        cells.forEachIndexed { i, v ->
            v.text = symbols.random()
            ObjectAnimator.ofFloat(v, "rotationX", 0f, 360f).apply {
                duration = 350L + i * 25
                start()
            }
        }
        val rows = cells.chunked(5)
        var win = 0L
        for (r in rows) {
            val counts = r.groupingBy { it.text.toString() }.eachCount()
            val best = counts.values.maxOrNull() ?: 1
            if (best >= 3) win += bet * best
        }
        if (Random.nextInt(100) < 12) win += bet * Random.nextInt(2,8)
        balance += win
        winText.text = "WIN\n$win"
        if (win > 0) tone.startTone(ToneGenerator.TONE_PROP_ACK, 300)
        refresh()
    }

    private fun refresh() {
        if (::balanceText.isInitialized) balanceText.text = "BALANCE  ${"%,d".format(balance)}"
        if (::betText.isInitialized) betText.text = "TOTAL BET\n${"%,d".format(bet)}"
    }

    override fun onDestroy() {
        tone.release()
        super.onDestroy()
    }
}
